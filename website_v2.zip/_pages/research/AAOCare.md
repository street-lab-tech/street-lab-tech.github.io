---
title: "STREET Lab - Designing Sustainable Reproductive Justice Futures"
layout: project
excerpt: "STREET Lab: Team projects"
sitemap: false
permalink: research/AAOCare.html
---
<div class="row" style="display: flex;">


<!--<div class="col-sm-5 clearfix" >
  <img src="{{ site.url }}{{ site.baseurl }}/images/pubpic/{{ project.photo }}" class="img-reponsive" width="100%" style="float: left" />
</div>-->

<div class="container-fluid">
  <h1>Designing Sustainable Reproductive Justice Futures</h1>
  <h3>Adrian Petterson</h3>
  <h4>Ongoing</h4>
  
</div>

</div>

<hr style="margin-top: 0.1rem;
  margin-bottom: 0.1rem;
  border: 0;
  border-top: 2px solid rgba(0, 0, 0, 0.2);"/>

<div class="row" style="display: flex;">

<div class=" col-sm-12">

<h3>Summary</h3>



<h3>Description</h3>

<h4>Updates</h4>


<br />