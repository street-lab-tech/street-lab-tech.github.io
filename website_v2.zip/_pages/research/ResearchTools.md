---
title: "STREET Lab - Research Tools"
layout: project
excerpt: "STREET Lab: Team projects"
sitemap: false
permalink: research/ResearchTools.html
---
<div class="row" style="display: flex;">


<!--<div class="col-sm-5 clearfix" >
  <img src="{{ site.url }}{{ site.baseurl }}/images/pubpic/{{ project.photo }}" class="img-reponsive" width="100%" style="float: left" />
</div>-->

<div class="container-fluid">
  <h1>Research Tools</h1>
  <h3>Emily Su, Carmen Chau, Priyank Chandra</h3>
  <h4>Ongoing</h4>
  
</div>

</div>

<hr style="margin-top: 0.1rem;
  margin-bottom: 0.1rem;
  border: 0;
  border-top: 2px solid rgba(0, 0, 0, 0.2);"/>

<div class="row" style="display: flex;">

<div class=" col-sm-12">
  <h3>Summary</h3>
STREET Lab is currently developing several applications to support qualitative research.

  <h3>Description</h3>
From interview transcription to qualitative coding, STREET Lab is creating offline applications that help lab members collect, sort and interpret data for organizing research material and other supplementary resources. 


<br />