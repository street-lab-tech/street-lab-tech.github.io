---
title: "The STREET Lab -- Research"
layout: gridlay
excerpt: "The STREET Lab -- Research"
sitemap: false
permalink: /research/
---
# Research

STREET Lab is focused on understanding and supporting the sociotechnical practices of marginalized communities around the world, with an emphasis in resistance, informality, and social justice.

Some broad research projects that we currently work on:

{% assign number_printed = 0 %}
{% for projects in site.data.projects %}

{% assign even_odd = number_printed | modulo: 2 %}
{% if projects.highlight == 1 %}

{% if even_odd == 0 %}
<div class="row">
{% endif %}

<div class="col-sm-6 clearfix">
 <div class="well clearfix">
  <pubtit>{{ projects.title }}</pubtit>
  <!--<img src="{{ site.url }}{{ site.baseurl }}/images/pubpic/{{ projects.image }}" class="img-responsive" width="33%" style="float: left" />-->
  <p>{{ projects.description }}</p>
  <p><b>Researchers:</b> {{ projects.authors }}</p>

{% if projects.subprojects != 0 %}  

  <p><b>Subprojects: </b></p>

  {% if projects.subprojects == 1 %}
  <ul><a href="{{ projects.subprojects1.url}}"> {{ projects.subprojects1.name}}</a></ul>
  {% endif %}

  {% if projects.subprojects == 2 %}
  <ul><a href="{{ projects.subprojects1.url}}"> {{ projects.subprojects1.name}}</a></ul>
  <ul><a href="{{ projects.subprojects2.url}}"> {{ projects.subprojects2.name}}</a></ul>
  {% endif %}

  {% if projects.subprojects == 3 %}
  <ul><a href="{{ projects.subprojects1.url}}"> {{ projects.subprojects1.name}}</a></ul>
  <ul><a href="{{ projects.subprojects2.url}}"> {{ projects.subprojects2.name}}</a></ul>
  <ul><a href="{{ projects.subprojects3.url}}"> {{ projects.subprojects3.name}}</a></ul>
  {% endif %}

  {% if projects.subprojects == 4 %}
  <ul><a href="{{ projects.subprojects1.url}}"> {{ projects.subprojects1.name}}</a></ul>
  <ul><a href="{{ projects.subprojects2.url}}"> {{ projects.subprojects2.name}}</a></ul>
  <ul><a href="{{ projects.subprojects3.url}}"> {{ projects.subprojects3.name}}</a></ul>
  <ul><a href="{{ projects.subprojects4.url}}"> {{ projects.subprojects4.name}}</a></ul>
  {% endif %}

  {% if projects.subprojects == 5 %}
  <ul><a href="{{ projects.subprojects1.url}}"> {{ projects.subprojects1.name}}</a></ul>
  <ul><a href="{{ projects.subprojects2.url}}"> {{ projects.subprojects2.name}}</a></ul>
  <ul><a href="{{ projects.subprojects3.url}}"> {{ projects.subprojects3.name}}</a></ul>
  <ul><a href="{{ projects.subprojects4.url}}"> {{ projects.subprojects4.name}}</a></ul>
  <ul><a href="{{ projects.subprojects5.url}}"> {{ projects.subprojects5.name}}</a></ul>
  {% endif %}

  {% endif %}

  <p><strong><a href="{{ projects.link.url }}">{{ projects.link.display }}</a></strong></p>
  
  {%- assign all_news = site.data.news | sort: "date" | reverse -%}
  {%- assign pid = projects.id -%}
  {%- assign proj_news = all_news | where_exp: "n", "n.projects and n.projects contains pid" -%}

  {%- assign news_limit = site.project_news_limit | default: 2 | plus: 0 -%}
  {%- for n in proj_news limit: news_limit -%}
    {%- assign label = n.title | default: n.headline -%}
    <p class="text-success">
      <strong>
        {%- if n.url and n.url != '' -%}<a href="{{ n.url }}">{{ label }}</a>{%- else -%}{{ label }}{%- endif -%}
      </strong>
      {%- if n.date -%}<span class="text-muted"> — {{ n.date | date: "%b %Y" }}</span>{%- endif -%}
    </p>
  {%- endfor -%}


 </div>
</div>

{% assign number_printed = number_printed | plus: 1 %}

{% if even_odd == 1 %}
</div>
{% endif %}

{% endif %}
{% endfor %}

{% assign even_odd = number_printed | modulo: 2 %}
{% if even_odd == 1 %}
</div>
{% endif %}

<p> &nbsp; </p>