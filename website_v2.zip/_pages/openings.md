---
title: "STREET Lab - Applying"
layout: textlay
excerpt: "Openings"
sitemap: false
permalink: /vacancies
---
# Job Openings

### Applications for PhD positions
If you are interested in working in the Lab as a PhD student, please send an email with your CV to [Prof. Priyank Chandra](mailto:priyank.chandra@utoronto.ca).
**Important**: please include _"Application PhD"_ in the subject line.

### Masters students at the Faculty of Information
If you are a Masters student looking to be part of any research project, contact Prof. Priyank Chandra (or any group member) by email. 
**Important**: please include _"STREET Lab: Application Masters"_ in the subject line.